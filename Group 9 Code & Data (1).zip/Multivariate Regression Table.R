library(haven)
library(stargazer)
setwd("/Users/sophiadavid/Desktop/GLBL 225/Afghanistan MICS6 Datasets/Afghanistan MICS6 SPSS Datasets")

# read in the data
wm <- read_sav("wm.sav")

# put relevant data into key data
key_data <- subset(wm, select = c(HH1, HH2, WB6A, WB6B, WAGEM, wmweight, WB4, WB3Y, HH6, wscore, UN16, UN17, UN18))
# Information on each relevant variable
  # HH1 = Cluster number
  # HH2 = Household number
  # WB6A = Highest level of school attended
  # WB6B = Highest grade attended at that level
  # WAGEM = Age at first marriage
  # wmweight = Woman's sample weight
  # WB4 = Age of woman
  # WB3Y = Year of birth (note: this is based on the Shamsi calender, but this does not impact our calculations)
  # HH6 = Area (rural or urban)
  # wscore = Combined wealth score
  # UN16 = Social activities, school days, or work not attended due to menstruation
  # UN17 = Availability of private washing facility during last menstruation
  # UN18 = Used any pads or tampons during last menstruation 
# Note: Explanations of all these variables were not included in the report. 
# To limit the word count, we only included explanations for the variables most relevant to our policy question. 

# filter out NAs from dependent variable
filtered_key_data <- subset(key_data, !is.na(WB6B))

# filter out " DK / NOT SURE / NO SUCH ACTIVITY" and "NO RESPONSE" from menstruation variables 
filtered_key_data2 <- subset(filtered_key_data, !is.na(UN16) & !(UN16 %in% c(8,9)))
filtered_key_data2 <- subset(filtered_key_data2, !is.na(UN17) & !(UN17 %in% c(8,9)))
filtered_key_data2 <- subset(filtered_key_data2, !is.na(UN18) & !(UN18 %in% c(8,9)))

# run the regression
regression <- lm(WB6B ~ WAGEM + HH6 + WB4 + WB3Y + UN16 + UN17 + UN18 + wscore, data = filtered_key_data2, weights = filtered_key_data2$wmweight)

# Make a table
table <- stargazer(regression, covariate.labels = c("Age at first marriage", "Urban/rural", "Age", "Year of Birth", "Social exclusion due to menstration", "Availability of washing during menstruation", "Access to menstrual products", "wealth score", "Constant"), type = "text")
  # Note: We used excel to create the final table used in our report in order to make the font match.

