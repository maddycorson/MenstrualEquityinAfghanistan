#-----------------------------------------------------------------------------
# Working R File for Final Policy Report
# Women's Access to Reproductive Health Surveys in Afghanistan (MICS6 Data)
# GLBL 225: Approaches to International Development 
#-----------------------------------------------------------------------------

#Alerting R to the important packages at use in the code:
library(haven)    # For uploading Stata data
library(ggplot2)  # For graphing 
library(flashlight) # For grouped_stats
library(dplyr)    # For summarize 
library(estimatr) # For robust standard errors replicating Stata results 

#Setting my working directory:
setwd("/Users/madelinecorson/Desktop/GLBL 225/Group Policy Project/Afghanistan MICS6 SPSS Datasets")

#Now, we can open and examine the data.
data_wm <- read_sav("wm.sav") 
View(data_wm)

#There were two other data files collected for the survey not opened here, but neither included variables of interest for our research question.
#The data is currently in long form, which is useful for the purposes of summarizing and graphing. 

#Since responses to UN18 are coded as 1, 2, 8, and 9, we must recode them as 0, 1 in a new data frame called "mh_access."
unique(data_wm$UN18)
#"Yes" is coded as 1, so we don't need to change this variable.
data_wm$mh_access[data_wm$UN18==1] <- 1 
#"No" is coded as 2, so we should recode this as 0. 
data_wm$mh_access[data_wm$UN18==2] <- 0 
#"Don't know" is coded as 8, so we should recode this as 0. "No response" is coded as 9, so we should also assume that these respondents have never attended
data_wm$mh_access[data_wm$UN18 == 8 & is.na(data_wm$mh_access)] <- NA
data_wm$mh_access[data_wm$UN18 == 9 & is.na(data_wm$mh_access)] <- NA

#We then prepare the graph by grouping menstrual health-related responses from the Women's Survey based on their educational attainment levels and calculating a weighted mean. 
#We use "wmweights," which will make our statistics representative. We exclude respondents who had NA responses to UN18!
mh_access_by_educ <- grouped_stats(data_wm, "mh_access", w = "wmweight", by="WB6A", na.rm = TRUE, stats = c("mean"))
#We multiple the newly-created weighted means column, mh_access, by 100 to find the percentages.
mh_access_by_educ$pct_mh_access <- mh_access_by_educ$mh_access*100
View(mh_access_by_educ)

#We must also manually construct confidence intervals. In order to do that, we first calculate the standard deviations of the data.
mh_access_by_educ$var <- grouped_stats(data_wm, "mh_access", w = "wmweight", by = "WB6A", na.rm = TRUE, stats = "variance")
mh_access_by_educ$sd <- sqrt(mh_access_by_educ$var)
#Then, we calculate the standard error and make a new variable for the z-score, assuming that the data is normally distributed.
mh_access_by_educ$se <- mh_access_by_educ$sd / sqrt(length(data_wm))
z_score <- 1.96
#Finally, we can calculate the confidence intervals.
mh_access_by_educ$conf_int_lower <- mh_access_by_educ$pct_mh_access - z_score * mh_access_by_educ$se
mh_access_by_educ$conf_int_upper <- mh_access_by_educ$pct_mh_access + z_score * mh_access_by_educ$se

#We can also double check the confidence intervals using a linear regression shortcut.
#Calculating the mean and standard error:
l.model <- lm(mh_access ~ 1, data_wm)
#Calculating the confidence interval:
confint(l.model, level=0.95)

#Let's relabel the educational attainment groups so that we can code the "no response" values as 0 with no overlap.
unique(data_wm$WB6A)
mh_access_by_educ$WB6A <- mh_access_by_educ$WB6A+1
mh_access_by_educ$WB6A[is.na(mh_access_by_educ$WB6A)] <- 0

#We can also order the data, create a factor variable for grade levels. 
unique(mh_access_by_educ$WB6A)
mh_access_by_educ <- mh_access_by_educ[order(mh_access_by_educ$WB6A), ]
mh_access_by_educ$grade <- factor(mh_access_by_educ$WB6A, label=c("Reported No Schooling", "Early Childhood Education", "Primary", "Lower Secondary", "Upper Secondary", "Higher", "Formal Islamic Education"))

#We are not using this code; this was just to check if it makes sense to graph as a box plot. However, since the confidence intervals are very small, we'll use a bar graph.
p<-ggplot(data_wm, aes(x=WB6A, y=mh_access, color=WB6A)) +
  geom_boxplot()
print(p)

#Here's our graphing code:
mh_access_and_educ <- ggplot(mh_access_by_educ, aes(x = grade, y = pct_mh_access)) +
  geom_bar(stat = "identity", fill = "#d11a4a") + 
  geom_text(aes(label = round(pct_mh_access, 2)), vjust = -0.5, color = "black", size = 3.5) +
  geom_text(aes(label = paste("(", round(se$mh_access, 2), ")", sep = "")), vjust = 1.5, color = "black", size = 3.5) + 
  theme_minimal() +  
  labs(x = "Educational Attainment", y = "Percentage of Access to Menstrual Products During Last Period") +
  ggtitle("Menstrual Product Access by Educational Attainment, 2022-2023") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  
        plot.title = element_text(hjust = 0.5),
        legend.position = "none")
print(mh_access_and_educ)

#Now, we can save the graph as a .png file.
ggsave("mh_access_and_educ.png", plot = mh_access_and_educ, width = 6, height = 8.5, units = "in", dpi = 300)

#-----------------------------------------------------------------------------
#Next, I'm going to repeat the same process but with UN16, which asks respondents to report social exclusion levels related to menstruation. 

#Since responses to UN16 are coded as 1, 2, 8, and 9, we must recode them as 0, 1 in a new data fram called "mh_access."
unique(data_wm$UN16)
#"Yes" is coded as 1, so we don't need to change this variable.
data_wm$mh_excl[data_wm$UN16==1] <- 1 
#"No" is coded as 2, so we should recode this as 0. 
data_wm$mh_excl[data_wm$UN16==2] <- 0 
#"Don't know" is coded as 8, so we should exclude this from the data. "No response" is coded as 9, so we should exclude this from the data, too.
data_wm$mh_excl[data_wm$UN16 == 8 & is.na(data_wm$mh_excl)] <- NA
data_wm$mh_excl[data_wm$UN16 == 9 & is.na(data_wm$mh_excl)] <- NA

#We then prepare the graph by grouping menstrual health-related responses from the Women's Survey based on their educational attainment levels and calculating a weighted mean. 
#We use "wmweights," which will make our statistics representative. We exclude respondents who had NA responses to UN16!
mh_excl_by_educ <- grouped_stats(data_wm, "mh_excl", w = "wmweight", by="WB6A", na.rm = TRUE, stats = c("mean"))
#We multiple the newly-created weighted means column, mh_excl, by 100 to find the percentages.
mh_excl_by_educ$pct_mh_excl <- mh_excl_by_educ$mh_excl*100
View(mh_excl_by_educ)

#As with before, we must also manually construct confidence intervals. In order to do that, we first calculate the standard deviations of the data.
mh_excl_by_educ$var <- grouped_stats(data_wm, "mh_excl", w = "wmweight", by = "WB6A", na.rm = TRUE, stats = "variance")
mh_excl_by_educ$sd <- sqrt(mh_excl_by_educ$var)
#Then, we calculate the standard error and make a new variable for the z-score, assuming that the data is normally distributed.
mh_excl_by_educ$se <- mh_excl_by_educ$sd / sqrt(length(data_wm))
z_score <- 1.96 #We did this before, but I've put it here for continuity. 
#Finally, we can calculate the confidence intervals.
mh_excl_by_educ$conf_int_lower <- mh_excl_by_educ$pct_mh_excl - z_score * mh_excl_by_educ$se
mh_excl_by_educ$conf_int_upper <- mh_excl_by_educ$pct_mh_excl + z_score * mh_excl_by_educ$se

#Let's relabel the educational attainment groups so that we can code the NA values as 0 with no overlap.
mh_excl_by_educ$WB6A <- mh_excl_by_educ$WB6A+1
mh_excl_by_educ$WB6A[is.na(mh_excl_by_educ$WB6A)] <- 0

#We can also order the data, create a factor variable for grade levels. 
unique(mh_excl_by_educ$WB6A)
mh_excl_by_educ <- mh_excl_by_educ[order(mh_excl_by_educ$WB6A), ]
mh_excl_by_educ$grade <- factor(mh_excl_by_educ$WB6A, label=c("Reported No Schooling", "Early Childhood Education", "Primary", "Lower Secondary", "Upper Secondary", "Higher", "Formal Islamic Education"))

#Now, let's generate the graph!
mh_excl_and_educ <- ggplot(mh_excl_by_educ, aes(x = grade, y = pct_mh_excl)) +
  geom_bar(stat = "identity", fill = "#FD9F00") + 
  geom_text(aes(label = round(pct_mh_excl, 2)), vjust = -0.5, color = "black", size = 3.5) +
  geom_text(aes(label = paste("(", round(se$mh_excl, 2), ")", sep = "")), vjust = 1.5, color = "black", size = 3.5) + 
  theme_minimal() +  
  labs(x = "Educational Attainment", y = "Percentage of Social Exclusion During Last Period") +
  ggtitle("Social Exclusion by Educational Attainment, 2022-2023") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  
        plot.title = element_text(hjust = 0.5),
        legend.position = "none")
print(mh_excl_and_educ)

#Finally, we can save the graph.
#Now, we can save the graph as a .png file.
ggsave("mh_excl_and_educ.png", plot = mh_excl_and_educ, width = 7, height = 9, units = "in", dpi = 300)

#-----------------------------------------------------------------------------
#Finally, I'm going to repeat the same process but with UN17, which asks respondents to report access to private place to wash themselves during their last menstrual cycle.
#Since responses to UN17 are coded as 1, 2, 8, and 9, we must recode them as 0, 1 in a new data fram called "mh_access."
unique(data_wm$UN17)
#"Yes" is coded as 1, so we don't need to change this variable.
data_wm$mh_wash[data_wm$UN17==1] <- 1 
#"No" is coded as 2, so we should recode this as 0. 
data_wm$mh_wash[data_wm$UN17==2] <- 0 
#"Don't know" is coded as 8, so we should exclude this from the data. "No response" is coded as 9, so we should exclude this from the data, too.
data_wm$mh_wash[data_wm$UN17 == 8 & is.na(data_wm$mh_wash)] <- NA
data_wm$mh_wash[data_wm$UN17 == 9 & is.na(data_wm$mh_wash)] <- NA

#We then prepare the graph by grouping menstrual health-related responses from the Women's Survey based on their educational attainment levels and calculating a weighted mean. 
#We use "wmweights," which will make our statistics representative. We exclude respondents who had NA responses to UN16!
mh_wash <- grouped_stats(data_wm, "mh_wash", w = "wmweight", by="WB6A", na.rm = TRUE, stats = c("mean"))
#We multiple the newly-created weighted means column, mh_wash, by 100 to find the percentages.
mh_wash$pct_mh_wash <- mh_wash$mh_wash*100
View(mh_wash)

#As with before, we must also manually construct confidence intervals. In order to do that, we first calculate the standard deviations of the data.
mh_wash$var <- grouped_stats(data_wm, "mh_wash", w = "wmweight", by = "WB6A", na.rm = TRUE, stats = "variance")
mh_wash$sd <- sqrt(mh_wash$var)
#Then, we calculate the standard error and make a new variable for the z-score, assuming that the data is normally distributed.
mh_wash$se <- mh_wash$sd / sqrt(length(data_wm))
z_score <- 1.96 #We did this before, but I've put it here for continuity. 
#Finally, we can calculate the confidence intervals.
mh_wash$conf_int_lower <- mh_wash$pct_mh_wash - z_score * mh_wash$se
mh_wash$conf_int_upper <- mh_wash$pct_mh_wash + z_score * mh_wash$se

#Let's relabel the educational attainment groups so that we can code the NA values as 0 with no overlap.
mh_wash$WB6A <- mh_wash$WB6A+1
mh_wash$WB6A[is.na(mh_wash$WB6A)] <- 0

#We can also order the data, create a factor variable for grade levels. 
unique(mh_wash$WB6A)
mh_wash <- mh_wash[order(mh_wash$WB6A), ]
mh_wash$grade <- factor(mh_wash$WB6A, label=c("Reported No Schooling", "Early Childhood Education", "Primary", "Lower Secondary", "Upper Secondary", "Higher", "Formal Islamic Education"))

#Now, let's generate the graph!
mh_wash_and_educ <- ggplot(mh_wash, aes(x = grade, y = pct_mh_wash)) +
  geom_bar(stat = "identity", fill = "#d11a4a") + 
  geom_text(aes(label = round(pct_mh_wash, 2)), vjust = -0.5, color = "black", size = 3.5) +
  geom_text(aes(label = paste("(", round(se$mh_wash, 2), ")", sep = "")), vjust = 1.5, color = "black", size = 3.5) + 
  theme_minimal() +  
  labs(x = "Educational Attainment", y = "Percentage Accessing Private Washing & Changing Facility During Last Period") +
  ggtitle("Private Washing & Changing Facility by Educational Attainment, 2022-2023") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),  
        plot.title = element_text(hjust = 0.5),
        legend.position = "none")
print(mh_wash_and_educ)

#Finally, we can save the graph.
#Now, we can save the graph as a .png file.
ggsave("mh_wash_and_educ.png", plot = mh_wash_and_educ, width = 7, height = 9, units = "in", dpi = 300)

#-----------------------------------------------------------------------------
#Next, I want to make a pie chart of the distribution of educational attainment levels among women in Afghanistan.

#To do this, we clean up the education variable.
data_wm$WB6A <- data_wm$WB6A+1
data_wm$WB6A[is.na(data_wm$WB6A)] <- 0
unique(data_wm$WB6A)
WB6A <- data_wm[order(data_wm$WB6A[is.na(data_wm$WB6A)] <- 0), ]
WB6A <- factor(data_wm$WB6A, label=c("No Reported Schooling", "Early Childhood Education", "Primary", "Lower Secondary", "Upper Secondary", "Higher", "Formal Islamic Education"))
data_wm$WB6A <- as.numeric(data_wm$WB6A) #This turns WB6A into a numeric variable.
weighted_category_sums <- aggregate(wmweight ~ WB6A, data = data_wm, sum)
print(weighted_category_sums)
weighted_population <- sum(data_wm$wmweight) #This line of code finds the weighted population value.
weighted_category_sums$pct_of_population <- (weighted_category_sums$wmweight / weighted_population) * 100 #This line of code calculates the percentages.

#We can use this code to look at the percentages and ensure they add to 100%. They do!
print(weighted_category_sums)

#We also need to make _weighted_category_sums a factor variable.
weighted_category_sums$WB6A <- factor(weighted_category_sums$WB6A, labels = c("No Reported Schooling", "Early Childhood Education", "Primary", "Lower Secondary", "Upper Secondary", "Higher", "Formal Islamic Education"))
View(weighted_category_sums)

#Finally, since the groups for Early Childhood Education and Formal Islamic Education are very small, we're going to eliminate their labels from the chart.
filtered_category_sums <- weighted_category_sums[!weighted_category_sums$WB6A %in% c("Early Childhood Education", "Formal Islamic Education"), ]

#Now, we can create a pie chart.
pie_chart <- ggplot(filtered_category_sums, aes(x = "", y = pct_of_population, fill = WB6A)) +
  geom_bar(stat = "identity", width = 1) +
  geom_text(aes(label = paste0(round(pct_of_population, 1), "%")), position = position_stack(vjust = 0.5)) +
  coord_polar("y", start = 0) +
  labs(title = "Percentage of Women by Education Level, 2022-2023", fill = "Educational Attainment", x = NULL, y = NULL) +
  theme_minimal() +
  theme(legend.position = "right")
print(pie_chart)

#Dont' forget to save it!
ggsave("pie_chart.png", plot = pie_chart, width = 7, height = 7, units = "in", dpi = 300)

#End of code.
